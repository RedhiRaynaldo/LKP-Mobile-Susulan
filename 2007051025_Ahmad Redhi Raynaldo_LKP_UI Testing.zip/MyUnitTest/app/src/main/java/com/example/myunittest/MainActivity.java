package com.example.myunittest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import com.example.myunittest.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ActivityMainBinding activityMainBinding;
    private MainViewModel mainViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setTitle("Menghitung Lingkaran");

        activityMainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(activityMainBinding.getRoot());

        mainViewModel = new MainViewModel(new CircleModel());

        activityMainBinding.btnSave.setOnClickListener(this);
        activityMainBinding.btnCalculateSurfaceArea.setOnClickListener(this);
        activityMainBinding.btnCalculateCircumference.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        String Jari = activityMainBinding.edtJari.getText().toString().trim();

        if (TextUtils.isEmpty(Jari)) {
            activityMainBinding.edtJari.setError("Field ini tidak boleh kosong");
        }  else {
            double valueJari = Double.parseDouble(Jari);

            if (v.getId() == R.id.btn_save) {
                mainViewModel.save(valueJari);
                visible();
            } else if (v.getId() == R.id.btn_calculate_circumference) {

                activityMainBinding.tvResult.setText(String.valueOf(mainViewModel.getCircumference()));
                gone();
            } else if (v.getId() == R.id.btn_calculate_surface_area) {

                activityMainBinding.tvResult.setText(String.valueOf(mainViewModel.getSurfaceArea()));
                gone();
            }
        }
    }
    private void visible() {
        activityMainBinding.btnCalculateCircumference.setVisibility(View.VISIBLE);
        activityMainBinding.btnCalculateSurfaceArea.setVisibility(View.VISIBLE);
        activityMainBinding.btnSave.setVisibility(View.GONE);
    }
    private void gone() {
        activityMainBinding.btnCalculateCircumference.setVisibility(View.GONE);
        activityMainBinding.btnCalculateSurfaceArea.setVisibility(View.GONE);
        activityMainBinding.btnSave.setVisibility(View.VISIBLE);
    }
}

