package com.example.myunittest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

import org.junit.Before;
import org.junit.Test;

public class MainViewModelTest {

    private MainViewModel mainViewModel;
    private CircleModel circleModel;

    private final double dummyJari = 4.0;
    private final double dummyCircumference = 25.12;
    private final double dummySurfaceArea = 50.24;

    @Before
    public void before() {
        circleModel = mock(CircleModel.class);
        mainViewModel = new MainViewModel(circleModel);
    }
    @Test
    public void testCircumference() {
        circleModel = new CircleModel();
        mainViewModel = new MainViewModel(circleModel);
        mainViewModel.save(dummyJari);
        double volume = mainViewModel.getCircumference();
        assertEquals(dummyCircumference, volume, 0.0001);
    }
    @Test
    public void tesSurfaceArea() {
        circleModel = new CircleModel();
        mainViewModel = new MainViewModel(circleModel);
        mainViewModel.save(dummyJari);
        double volume = mainViewModel.getSurfaceArea();
        assertEquals(dummySurfaceArea, volume, 0.0001);
    }

}