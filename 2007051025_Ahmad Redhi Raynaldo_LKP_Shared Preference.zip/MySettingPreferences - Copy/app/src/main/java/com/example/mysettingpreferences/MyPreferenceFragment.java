package com.example.mysettingpreferences;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.preference.CheckBoxPreference;
import androidx.preference.EditTextPreference;
import androidx.preference.PreferenceFragmentCompat;
public class MyPreferenceFragment extends PreferenceFragmentCompat implements SharedPreferences.OnSharedPreferenceChangeListener {
    private String DEFAULT_VALUE = "Tidak Ada";
    private String NAME;
    private String EMAIL;
    private String NIK;
    private String PHONE;
    private String VAKSIN;
    private EditTextPreference namePreference;
    private EditTextPreference emailPreference;
    private EditTextPreference nikPreference;
    private EditTextPreference phonePreference;
    private CheckBoxPreference vaksinPreference;

    @Override
    public void onCreatePreferences(Bundle bundle, String s) {
        addPreferencesFromResource(R.xml.preferences);
        init();
        setSummeries();
    }

    private void setSummeries() {
        SharedPreferences sh =
                getPreferenceManager().getSharedPreferences();
        namePreference.setSummary(sh.getString(NAME, DEFAULT_VALUE));
        emailPreference.setSummary(sh.getString(EMAIL, DEFAULT_VALUE));
        nikPreference.setSummary(sh.getString(NIK, DEFAULT_VALUE));
        phonePreference.setSummary(sh.getString(PHONE, DEFAULT_VALUE));
        vaksinPreference.setChecked(sh.getBoolean(VAKSIN, false));
    }

    private void init() {
        NAME = getResources().getString(R.string.key_name);
        EMAIL = getResources().getString(R.string.key_email);
        NIK = getResources().getString(R.string.key_nik);
        PHONE = getResources().getString(R.string.key_phone);
        VAKSIN = getResources().getString(R.string.key_vaksin);
        namePreference = (EditTextPreference) findPreference(NAME);
        emailPreference = (EditTextPreference) findPreference(EMAIL);
        nikPreference = (EditTextPreference) findPreference(NIK);
        phonePreference = (EditTextPreference) findPreference(PHONE);
        vaksinPreference = (CheckBoxPreference) findPreference(VAKSIN);

    }

    @Override
    public void onResume(){
        super.onResume();
        getPreferenceScreen().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }
    @Override
    public void onPause(){
        super.onPause();
        getPreferenceScreen().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences
                                                  sharedPreferences, String key) {
        if (key.equals(NAME)) {
            namePreference.setSummary(sharedPreferences.getString(NAME,
                    DEFAULT_VALUE));
        }
        if (key.equals(EMAIL)) {
            emailPreference.setSummary(sharedPreferences.getString(EMAIL,
                    DEFAULT_VALUE));
        }
        if (key.equals(NIK)) {
            nikPreference.setSummary(sharedPreferences.getString(NIK,
                    DEFAULT_VALUE));
        }
        if (key.equals(PHONE)) {
            phonePreference.setSummary(sharedPreferences.getString(PHONE,
                    DEFAULT_VALUE));
        }
        if (key.equals(VAKSIN)) {
            vaksinPreference.setChecked(sharedPreferences.getBoolean(VAKSIN, false));
        }
    }

}
