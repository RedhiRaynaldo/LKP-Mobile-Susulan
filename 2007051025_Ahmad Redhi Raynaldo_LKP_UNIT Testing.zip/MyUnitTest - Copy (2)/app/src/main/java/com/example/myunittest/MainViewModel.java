package com.example.myunittest;

public class MainViewModel {
    private final CircleModel circleModel;
    MainViewModel(CircleModel circleModel) {
        this.circleModel = circleModel;
    }
    void save(double jari) {
        circleModel.save(jari);
    }
    double getCircumference() {
        return circleModel.getCircumference();
    }
    double getSurfaceArea() {
        return circleModel.getSurfaceArea();
    }
}
