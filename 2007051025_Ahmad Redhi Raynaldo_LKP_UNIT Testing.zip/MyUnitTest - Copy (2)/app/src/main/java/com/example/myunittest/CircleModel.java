package com.example.myunittest;

public class CircleModel {
    private double jari;

    public CircleModel() {
    }
    public void save(double jari) {
        this.jari = jari;
    }
    public double getSurfaceArea() {

        return 3.14 * jari * jari;
    }
    public double getCircumference() {
        return 2 * 3.14 * jari;
    }
}
